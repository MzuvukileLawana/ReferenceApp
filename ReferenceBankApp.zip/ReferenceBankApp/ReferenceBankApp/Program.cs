﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReferenceBankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Reference: ");
                var reference = Console.ReadLine();
                int x = 0;

                var number = reference.Substring(2, 8);

                int[] weighting = new int[7] { 1, 3, 7, 1, 3, 7, 1 };

                if (reference.Length == 10 && reference.Substring(0, 2).Equals("CF") && Int32.TryParse(number, out x))
                {
                    var checkTotal = 0;
                    var removeLastNumber = number.Substring(0, 7);



                    
                    for (int i = 0; i < removeLastNumber.Length; i++)
                    {
                        if (removeLastNumber[i] != '0')
                        {

                            checkTotal = checkTotal + (Int32.Parse(removeLastNumber[i].ToString()) * weighting[i]);

                        }
                    }
                    var remainder = checkTotal % 10;
                    var tenChar = 10 - remainder;
                    if (reference[9].ToString().Equals(tenChar.ToString()))
                    {
                        Console.WriteLine("Success reference entered");
                    }
                    else
                    {
                        Console.WriteLine("Invalid reference entered");
                    }

                }
                else
                {
                    Console.WriteLine("Invalid reference entered ");
                }
            }
            catch
            {
                throw;
            }

            Console.WriteLine("");
            Console.WriteLine("Press enter to exit");
            Console.ReadKey();
        }
    }
}
